Page({
  data: {
    searchKeyword: '',
    currentCategory: 1,
    cartCount: 0,
    loading: false,
    noMore: false,
    categories: [
      { id: 1, name: '全部' },
      { id: 2, name: '口腔护理' },
      { id: 3, name: '美白产品' },
      { id: 4, name: '儿童专区' },
      { id: 5, name: '口腔工具' },
      { id: 6, name: '术后护理' }
    ],
    goodsList: [
      {
        id: 1,
        name: '德国进口电动牙刷',
        description: '4种清洁模式，智能压力感应',
        price: 299,
        originalPrice: 499,
        soldCount: 1234,
        image: 'images/innermirror_1.jpg',
        tags: ['正品保障', '全球直采']
      },
      {
        id: 2,
        name: '专业美白牙膏套装',
        description: '温和配方，持久清新',
        price: 128,
        originalPrice: 168,
        soldCount: 3456,
        image: 'images/innermirror_2.jpg',
        tags: ['限时特惠', '买二赠一']
      }
      // ... 更多商品
    ]
  },

  onLoad() {
    this.loadCartCount();
  },

  loadCartCount() {
    // 从缓存或服务器获取购物车数量
    this.setData({
      cartCount: 2
    });
  },

  onSearchInput(e) {
    this.setData({
      searchKeyword: e.detail.value
    });
    this.searchGoods();
  },

  searchGoods() {
    // 实现搜索逻辑
    console.log('搜索关键词：', this.data.searchKeyword);
  },

  switchCategory(e) {
    const categoryId = e.currentTarget.dataset.id;
    this.setData({
      currentCategory: categoryId
    });
    this.loadGoodsList(categoryId);
  },

  loadGoodsList(categoryId) {
    // 根据分类加载商品列表
    console.log('加载分类：', categoryId);
  },

  loadMore() {
    if (this.data.loading || this.data.noMore) return;
    
    this.setData({ loading: true });
    // 模拟加载更多
    setTimeout(() => {
      this.setData({
        loading: false,
        noMore: true
      });
    }, 1000);
  },

  onRefresh() {
    // 下拉刷新
    setTimeout(() => {
      wx.stopPullDownRefresh();
    }, 1000);
  },

  navigateToDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/service-detail/index?id=${id}`
    });
  },

  navigateToCart() {
    wx.switchTab({
      url: '/pages/cart/index'
    });
  },

  toProductDetail() {
    wx.navigateTo({
      url: '/page/exchangegoods/index',
    })
  }
}); 